package Jeu;

public enum Direction {
	HAUT,
	BAS,
	GAUCHE,
	DROITE;
}
