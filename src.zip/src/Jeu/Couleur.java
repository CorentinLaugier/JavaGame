package Jeu;

public class Couleur {
    Extremite extremite1;
    Extremite extremite2;
    Ligne ligne;
    String name;
    
    Ligne getLigneDepart(Extremite depart) {
        ligne.setArrivee(null);
        ligne.setDepart(depart);
        ligne.miseZero();
        return ligne;
    }

    Couleur(String name){
        this.name = name;
        this.extremite1 = null;
        this.extremite2 = null;
        this.ligne = new Ligne(this);
    }
    
    String getName() {
    	return this.name;
    }

    void addExtremite(Extremite extremite){
        if(this.extremite1 == null){
            this.extremite1 = extremite;
        }
        else if(this.extremite2 == null){
            this.extremite2 = extremite;
        }
        else{
            System.out.println("Vous avez essayé d'ajouter une troisieme extremité");
        }
    }
}