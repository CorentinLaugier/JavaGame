package Jeu;

import java.util.Scanner;

public class Controleur {
    Plateau plateau;
    Ligne ligneCourante = null;
    
    public Controleur(Plateau plateau){
        this.plateau = plateau;
    }
    
    public void selectionLigne(int ligne, int colonne) {
        ligneCourante = plateau.getLigne(ligne, colonne);
    }

    
    public void action(Direction direction) {
        Case caseCourante = ligneCourante.getDerniere();
    	Case caseSuivante = plateau.getMaCaseVoisine(caseCourante, direction);
    	if (caseSuivante.accepteLigne()){
    	    ligneCourante.ajouteCase(caseSuivante);
        }

    }
}
