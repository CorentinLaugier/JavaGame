package Jeu;

public class Extremite {

	Case position;
	Couleur couleur;
	Ligne ligneDepart = null;
	Ligne ligneArrivee = null;

	Extremite(Case position,Couleur couleur){
		this.position = position;
		this.couleur = couleur;
		couleur.addExtremite(this);
	}
	
	Couleur getCouleur() {
		return this.couleur;
	}
	
	Case getCase() {
		return this.position;
	}
	
	Ligne getLigne() {
		if (ligneDepart != null){
			return ligneDepart;
		}
		else{
			return this.couleur.getLigneDepart(this);
		}
	}

	boolean valideFinJeu() {
		if (ligneDepart != null) {
			return ligneDepart.valideFinJeu();
		}
		if (ligneArrivee != null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	boolean accepteLigne(Ligne ligne) {
		if(ligne.getCouleur()==this.couleur){
			if(ligneDepart==null&&ligneArrivee==null){
				 return true;
			}
		}
		return false;
	}
	
	void oubliLigneDepart() {
		
	}
}
