package Jeu;

import java.util.ArrayList;
import java.util.List;

public class Ligne {
    Couleur couleur;
    Extremite depart = null;
    Extremite arrivee = null;
    List<Case> casesUtilisees = new ArrayList<>();
    
    void modifier(Direction direction) {
    	
    }

    Ligne(Couleur couleur){
        this.couleur = couleur;;
    }
    
    void setDepart(Extremite depart) {
    	this.depart = depart;
    }
    
    void ajouteCase(Case carre) {
        casesUtilisees.add(carre);
        carre.setLigne(this);
    }

    void miseZero(){
        for(Case caseParcours : casesUtilisees){
            caseParcours.ligneSupprimee();
        }
        casesUtilisees.clear();
    }
    
    boolean valideFinJeu() {
    	if (arrivee == null || depart == null)
    		return false;
    	return true;
    }

    Case getDerniere(){
        if (casesUtilisees.size() != 0)
            return casesUtilisees.get(casesUtilisees.size()-1);
        else return depart.getCase();
    }

    Couleur getCouleur() {
    	return this.couleur;
    }
    
    Extremite getDepart() {
    	return null;
    }
    
    void setArrivee(Extremite arrivee) {
    	this.arrivee = arrivee;
    }
}
