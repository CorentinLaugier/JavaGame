package Jeu;

import java.awt.*;
import java.util.Scanner;

public class Jouer {
    public static void main(String[] args) {
        Plateau plateau = new Plateau(5);
        Controleur controleur = new Controleur(plateau);
        Couleur rouge = new Couleur("Rouge");
        plateau.ajouteExtremite(1,1,rouge);
        plateau.ajouteExtremite(3,3,rouge);
        System.out.println(plateau);


        Scanner in = new Scanner(System.in);
        int ligne;
        int colonne;
        System.out.println("Quelle ligne ?");
        ligne = in.nextInt();
        System.out.println("Quelle colonne ?");
        colonne = in.nextInt();
        controleur.selectionLigne(ligne, colonne);

        if (controleur.ligneCourante != null){
            Scanner in2 = new Scanner(System.in);
            Direction suivant;
            String direction;
            System.out.println("Quelle direction ? (haut,bas,gauche,droite)");
            direction = in2.nextLine();
            if(direction.equals("haut")){
                suivant = Direction.HAUT;
            }
            else if(direction.equals("bas")){
                suivant = Direction.BAS;
            }
            else if(direction.equals("droite")){
                suivant = Direction.DROITE;
            }
            else{
                suivant = Direction.GAUCHE;
            }
            controleur.action(suivant);

        }

        System.out.println(plateau);

    }
}
