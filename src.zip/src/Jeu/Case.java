package Jeu;

public class Case {
    boolean utiliseExtremite;
    boolean utiliseLigne;
    Extremite extremite;
    Ligne lignePassante;
    Plateau plateau;

    public Case(Plateau plateau){
        utiliseExtremite = false;
        utiliseLigne = false;
        extremite = null;
        lignePassante = null;
        this.plateau = plateau;
    }

    void setExtremite(Couleur couleur){
        this.extremite = new Extremite(this, couleur);
        utiliseExtremite = true;
    }

    void setLigne(Ligne ligne){
        this.lignePassante = ligne;
        utiliseLigne = true;
    }
    
    Ligne getLigne() {
    	if(utiliseExtremite){
    	    return extremite.getLigne();
        }
    	else if(utiliseLigne){
    	    return lignePassante;
        }
    	else{
    	    return null;
        }
    }
    
    Case getCaseVoisine(Direction direction) {
    	return plateau.getMaCaseVoisine(this, direction);
    }
    
    boolean valideFinJeu() {
    	if (utiliseExtremite) {
    		return extremite.valideFinJeu();
    	}
    	if (utiliseLigne) {
    		return true;
    	}
    	return false;
    }
    
    boolean accepteLigne() {
    	if(!utiliseLigne&&!utiliseExtremite){
    	    return true;
        }
    	else{
    	    return false;
        }
    }
    
    void ligneSupprimee() {
    	utiliseLigne = false;
    	lignePassante = null;
    }
}
