package Jeu;


public class Plateau {
    Case[][] listCase;
    int dimension;
    
    public Plateau(int dimension){
        this.dimension = dimension;
        listCase = new Case[dimension][dimension];
        for(int i = 0; i<dimension; i++){
            for(int j = 0; j<dimension; j++){
                listCase[i][j] = new Case(this);
            }
        }
    }
    
    int[] getPosition(Case moi) {
    	for (int i=0; i<this.dimension; ++i) {
    		for (int j=0; j<this.dimension; ++j){
    			if (listCase[i][j] == moi) {
    				return new int[] {i,j};
    			} 
    		}
    	}
    	return new int[2] ;
    }

    Case getCase(int ligne, int colonne){
        return listCase[ligne][colonne];
    }

    Ligne getLigne(int ligne, int colone) {
    	return listCase[ligne][colone].getLigne();
    }

    Case getMaCaseVoisine(Case moi, Direction direction) {
    	int[] position = getPosition(moi);
    	int ligne = position[0];
    	int colonne = position[1];
    	
    	switch (direction) {
    	case HAUT:
    		if (ligne != 0) {
    			return listCase[ligne-1][colonne];
    		}
    		return null;
    		
    	case BAS:
    		if (ligne != dimension-1) {
    			return listCase[ligne+1][colonne];
    		}
    		return null;
    		
    	case DROITE:
    		if (colonne != dimension-1) {
    			return listCase[ligne][colonne+1];
    		}
    		return null;
    		
    	case GAUCHE:
    		if (colonne != 0) {
    			return listCase[ligne][colonne-1];
    		}
    		return null;
    	}
    		
    	return null;
    }
    
    boolean plateauComplet() {
    	for (int i=0; i<this.dimension; ++i) {
    		for (int j=0; j<this.dimension; ++j){
    			if (!listCase[i][j].valideFinJeu()){
    				return false;
    			}
    		}
    	}
    	return true;
    }

    void ajouteExtremite(int ligne, int colonne, Couleur couleur){
        Case caseExtremite = this.getCase(ligne,colonne);
        caseExtremite.setExtremite(couleur);
    }

    public String toString() {
        String res = "";
        for (int i=0; i<this.dimension; ++i) {
            res += "--";
        }
        res += "\n";
        for (int i=0; i<this.dimension; ++i) {
            res += "|";
            for (int j=0; j<this.dimension; ++j) {
                if (listCase[i][j].utiliseExtremite) {
                	String couleur = listCase[i][j].extremite.getCouleur().getName();
                	res += couleur.substring(0, 1);
                }
                else if(listCase[i][j].utiliseLigne){
                	String couleur = listCase[i][j].lignePassante.getCouleur().getName();
                	res += couleur.substring(0, 1);
                }
                else {
                    res += " ";
                }
                res += "|";
            }
            res += "\n";

            for (int j=0; j<this.dimension; ++j) {
                res += "--";
            }
            res += "\n";
        }
        return res;
    }
}