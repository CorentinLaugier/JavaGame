package Jeu;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {



//        Plateau plateauComplet = new Plateau(2);
//        Controleur controleur2 = new Controleur(plateauComplet);
//        Couleur vert = new Couleur("Vert");
//        Couleur bleu = new Couleur("Bleu");
//        plateauComplet.ajouteExtremite(0,0,vert);
//        plateauComplet.ajouteExtremite(0,1,vert);
//        plateauComplet.ajouteExtremite(1,0,bleu);
//        plateauComplet.ajouteExtremite(1,1,bleu);
//
//
//        System.out.println(plateauComplet);
//        System.out.println(plateauComplet.plateauComplet());
        

        //Case l0c1 : plateau
//        l0c2 : plateau
//        l0c3 : plateau
//        l0c4 : plateau - e_rouge_1
//        l1c0 : plateau - e_orange_1
//        l1c1 : plateau
//        l1c2 : plateau
//        l1c3 : plateau
//        l1c4 : plateau
//        l2c0 : plateau - e_bleu_1
//        l2c1 : plateau - e_vert_1
//        l2c2 : plateau
//        l2c3 : plateau - e_vert_2
//        l2c4 : plateau
//        l3c0 : plateau
//        l3c1 : plateau
//        l3c2 : plateau
//        l3c3 : plateau
//        l3c4 : plateau
//        l4c0 : plateau - e_bleu_2
//        l4c1 : plateau - e_orange_2
//        l4c2 : plateau - e_jaune_1
//        l4c3 : plateau
//        l4c4 : plateau - e_jaune_2

    }
}
